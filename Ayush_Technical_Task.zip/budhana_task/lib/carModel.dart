class CarDetails {
  String name;
  String type;
  String price;
  String url;

  CarDetails(
      {required this.name,
      required this.price,
      required this.type,
      required this.url});
}
